package com.fastcampus.admin.repository;

import com.fastcampus.admin.ApplicationTest;
import com.fastcampus.admin.model.entity.ApplyCourse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

public class ApplyCourseRepositoryTest extends ApplicationTest {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ApplyCourseRepository applyCourseRepository;

    @Test
    public void create() {
        ApplyCourse applyCourse = createApplyCourse(courseRepository,
                studentRepository,
                applyCourseRepository);
        Assertions.assertNotNull(applyCourse);
    }

    public static ApplyCourse createApplyCourse(CourseRepository courseRepository,
                                                StudentRepository studentRepository,
                                                ApplyCourseRepository applyCourseRepository) {
        ApplyCourse applyCourse = new ApplyCourse();
        applyCourse.setStatus("test");
        applyCourse.setExpireAt(LocalDateTime.now());
        applyCourse.setCreatedAt(LocalDateTime.now());
        applyCourse.setCreatedBy("test");

        applyCourse.setCourse(CourseRepositoryTest.createCourse(courseRepository));
        applyCourse.setStudent(StudentRepositoryTest.createStudent(studentRepository));

        return applyCourseRepository.save(applyCourse);
    }
}
