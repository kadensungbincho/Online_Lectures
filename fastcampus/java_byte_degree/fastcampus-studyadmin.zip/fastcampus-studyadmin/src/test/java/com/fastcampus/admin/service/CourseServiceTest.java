package com.fastcampus.admin.service;

import com.fastcampus.admin.ApplicationTest;
import com.fastcampus.admin.network.Header;
import com.fastcampus.admin.network.request.CourseApiRequest;
import com.fastcampus.admin.network.response.CourseApiResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

public class CourseServiceTest extends ApplicationTest {

    @Autowired
    private CourseService courseService;

    @Test
    public void create() {
        CourseApiRequest courseApiRequest = new CourseApiRequest();
        courseApiRequest.setTitle("test");
        courseApiRequest.setStatus("test");
        courseApiRequest.setTeacherName("test");
        courseApiRequest.setTeacherPhoneNumber("test");
        courseApiRequest.setTeacherEmail("test");
        courseApiRequest.setAmount(BigDecimal.valueOf(12.01));

        Header<CourseApiResponse> response = courseService.create(Header.OK(courseApiRequest));
        Assertions.assertEquals(response.getResultCode(), "OK");
    }
}
