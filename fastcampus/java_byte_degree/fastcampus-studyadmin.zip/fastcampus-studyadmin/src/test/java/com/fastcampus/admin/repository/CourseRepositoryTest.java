package com.fastcampus.admin.repository;

import com.fastcampus.admin.ApplicationTest;
import com.fastcampus.admin.model.entity.Course;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class CourseRepositoryTest extends ApplicationTest {

    @Autowired
    private CourseRepository courseRepository;

    @Test
    public void create() {
        Course newCourse = createCourse(courseRepository);
        Assertions.assertNotNull(newCourse);
    }

    public static Course createCourse(CourseRepository courseRepository) {
        Course course = new Course();
        course.setId(1L);
        course.setTitle("test");
        course.setStatus("test");
        course.setTeacherName("test");
        course.setCreatedAt(LocalDateTime.now());
        course.setCreatedBy("test");
        course.setAmount(BigDecimal.valueOf(12.01));

        return courseRepository.save(course);
    }
}
