package com.fastcampus.admin.repository;

import com.fastcampus.admin.ApplicationTest;
import com.fastcampus.admin.model.entity.Course;
import com.fastcampus.admin.model.entity.CourseDetail;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

public class CourseDetailRepositoryTest extends ApplicationTest {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private CourseDetailRepository courseDetailRepository;

    private Course course;

    @BeforeEach
    public void createCourse() {
        this.course = CourseRepositoryTest.createCourse(courseRepository);
    }

    @Test
    public void create() {
        CourseDetail courseDetail = new CourseDetail();
        courseDetail.setTitle("test");
        courseDetail.setCreatedAt(LocalDateTime.now());
        courseDetail.setCreatedBy("test");
        courseDetail.setCourse(this.course);

        CourseDetail newCourseDetail = courseDetailRepository.save(courseDetail);
        Assertions.assertNotNull(newCourseDetail);
    }
}
