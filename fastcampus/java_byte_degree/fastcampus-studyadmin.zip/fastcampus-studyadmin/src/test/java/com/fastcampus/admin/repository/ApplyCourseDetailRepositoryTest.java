package com.fastcampus.admin.repository;

import com.fastcampus.admin.ApplicationTest;
import com.fastcampus.admin.model.entity.ApplyCourse;
import com.fastcampus.admin.model.entity.ApplyCourseDetail;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

public class ApplyCourseDetailRepositoryTest extends ApplicationTest {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ApplyCourseRepository applyCourseRepository;

    @Autowired
    private ApplyCourseDetailRepository applyCourseDetailRepository;

    @Test
    public void create() {
        ApplyCourseDetail applyCourseDetail = new ApplyCourseDetail();
        applyCourseDetail.setCreatedAt(LocalDateTime.now());
        applyCourseDetail.setCreatedBy("test");

        ApplyCourse applyCourse = ApplyCourseRepositoryTest.createApplyCourse(courseRepository,
                studentRepository,
                applyCourseRepository);
        applyCourseDetail.setApplyCourse(applyCourse);

        ApplyCourseDetail newApplyCourseDetail = applyCourseDetailRepository.save(applyCourseDetail);
        Assertions.assertNotNull(newApplyCourseDetail);
    }
}
