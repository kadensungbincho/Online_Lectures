package com.fastcampus.admin.repository;

import com.fastcampus.admin.ApplicationTest;
import com.fastcampus.admin.model.entity.Student;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

public class StudentRepositoryTest extends ApplicationTest {

    @Autowired
    private StudentRepository studentRepository;

    @Test
    public void create() {
        Student newStudent = createStudent(studentRepository);
        Assertions.assertNotNull(newStudent);
    }

    public static Student createStudent(StudentRepository studentRepository) {
        Student student = new Student();
        student.setId(1L);
        student.setAccount("test");
        student.setPassword("test");
        student.setStatus("test");
        student.setPhoneNumber("test");
        student.setCreatedAt(LocalDateTime.now());
        student.setCreatedBy("test");

        return studentRepository.save(student);
    }
}
