package com.fastcampus.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplicationTest {

    @Test
    void contextLoads() {
        System.out.println("Loads Test Context");
    }
}
