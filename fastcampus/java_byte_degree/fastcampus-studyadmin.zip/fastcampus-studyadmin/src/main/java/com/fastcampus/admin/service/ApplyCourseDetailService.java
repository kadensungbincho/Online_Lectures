package com.fastcampus.admin.service;

import com.fastcampus.admin.model.entity.ApplyCourse;
import com.fastcampus.admin.model.entity.ApplyCourseDetail;
import com.fastcampus.admin.network.Header;
import com.fastcampus.admin.network.request.ApplyCourseDetailApiRequest;
import com.fastcampus.admin.network.response.ApplyCourseApiResponse;
import com.fastcampus.admin.network.response.ApplyCourseDetailApiResponse;
import com.fastcampus.admin.repository.ApplyCourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplyCourseDetailService extends BaseService<ApplyCourseDetailApiRequest, ApplyCourseDetailApiResponse, ApplyCourseDetail> {

    @Autowired
    private ApplyCourseRepository applyCourseRepository;

    @Override
    public Header<ApplyCourseDetailApiResponse> create(Header<ApplyCourseDetailApiRequest> request) {
        ApplyCourseDetailApiRequest body = request.getData();

        if (body != null) {
            ApplyCourseDetail applyCourseDetail = ApplyCourseDetail.builder()
                    .applyCourse(applyCourseRepository.getOne(body.getApplyCourseId()))
                    .build()
                    ;

            ApplyCourseDetail newApplyCourseDetail = baseRepository.save(applyCourseDetail);

            return response(newApplyCourseDetail);
        }

        return Header.ERROR("Empty body");
    }

    @Override
    public Header<ApplyCourseDetailApiResponse> read(Long id) {
        return baseRepository.findById(id)
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No ApplyCourseDetail to read"));
    }

    @Override
    public Header<ApplyCourseDetailApiResponse> update(Header<ApplyCourseDetailApiRequest> request) {
        ApplyCourseDetailApiRequest body = request.getData();

        return baseRepository.findById(body.getId())
                .map(entityApplyCourseDetail -> {
                    entityApplyCourseDetail
                            .setApplyCourse(applyCourseRepository.getOne(body.getApplyCourseId()))
                            ;

                    return entityApplyCourseDetail;
                })
                .map(newApplyCourseDetail -> baseRepository.save(newApplyCourseDetail))
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No ApplyCourseDetail to update"));
    }

    @Override
    public Header delete(Long id) {
        return baseRepository.findById(id)
                .map(applyCourseDetail -> {
                    baseRepository.delete(applyCourseDetail);
                    return Header.OK();
                })
                .orElseGet(() -> Header.ERROR("No ApplyCourseDetail to delete"));
    }

    private Header<ApplyCourseDetailApiResponse> response(ApplyCourseDetail applyCourseDetail) {
        ApplyCourseDetailApiResponse body = ApplyCourseDetailApiResponse.builder()
                .applyCourseId(applyCourseDetail.getApplyCourse().getId())
                .build()
                ;

        return Header.OK(body);
    }
}
