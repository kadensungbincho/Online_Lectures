package com.fastcampus.admin.network.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplyCourseApiResponse {

    private Long id;

    private String status;

    private double progressRate;

    private String isComplete;

    private LocalDateTime expireAt;

    private Long courseId;

    private Long studentId;
}
