package com.fastcampus.admin.repository;

import com.fastcampus.admin.model.entity.CourseDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseDetailRepository extends JpaRepository<CourseDetail, Long> {
}
