package com.fastcampus.admin.controller.api;

import com.fastcampus.admin.controller.CrudController;
import com.fastcampus.admin.model.entity.CourseDetail;
import com.fastcampus.admin.network.request.CourseDetailApiRequest;
import com.fastcampus.admin.network.response.CourseDetailApiResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/courseDetail")
public class CourseDetailController extends CrudController<CourseDetailApiRequest, CourseDetailApiResponse, CourseDetail> {
}
