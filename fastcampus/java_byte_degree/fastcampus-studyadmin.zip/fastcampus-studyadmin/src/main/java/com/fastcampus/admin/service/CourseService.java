package com.fastcampus.admin.service;

import com.fastcampus.admin.model.entity.Course;
import com.fastcampus.admin.network.Header;
import com.fastcampus.admin.network.request.CourseApiRequest;
import com.fastcampus.admin.network.response.CourseApiResponse;
import org.springframework.stereotype.Service;

@Service
public class CourseService extends BaseService<CourseApiRequest, CourseApiResponse, Course> {

    @Override
    public Header<CourseApiResponse> create(Header<CourseApiRequest> request) {
        CourseApiRequest body = request.getData();

        if (body != null) {
            Course course = Course.builder()
                    .title(body.getTitle())
                    .status(body.getStatus())
                    .teacherName(body.getTeacherName())
                    .teacherPhoneNumber(body.getTeacherPhoneNumber())
                    .teacherEmail(body.getTeacherEmail())
                    .amount(body.getAmount())
                    .build()
                    ;
            Course newCourse = baseRepository.save(course);
            return response(newCourse);
        }

        return Header.ERROR("Empty Body");
    }

    @Override
    public Header<CourseApiResponse> read(Long id) {
        return baseRepository.findById(id)
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No Course to read"));
    }

    @Override
    public Header<CourseApiResponse> update(Header<CourseApiRequest> request) {
        CourseApiRequest body = request.getData();

        return baseRepository.findById(body.getId())
                .map(entityCourse -> {
                    entityCourse
                            .setTitle(body.getTitle())
                            .setStatus(body.getStatus())
                            .setTeacherName(body.getTeacherName())
                            .setTeacherPhoneNumber(body.getTeacherPhoneNumber())
                            .setTeacherEmail(body.getTeacherEmail())
                            .setAmount(body.getAmount())
                            ;
                    return entityCourse;
                })
                .map(newEntityCourse -> baseRepository.save(newEntityCourse))
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No Course to update"));
    }

    @Override
    public Header delete(Long id) {
        return baseRepository.findById(id)
                .map(course -> {
                    baseRepository.delete(course);
                    return Header.OK();
                })
                .orElseGet(() -> Header.ERROR("No Course to delete"));
    }

    private Header<CourseApiResponse> response(Course course) {
        CourseApiResponse body = CourseApiResponse.builder()
                .id(course.getId())
                .title(course.getTitle())
                .status(course.getStatus())
                .teacherName(course.getTeacherName())
                .teacherPhoneNumber(course.getTeacherPhoneNumber())
                .teacherEmail(course.getTeacherEmail())
                .amount(course.getAmount())
                .build()
                ;
        return Header.OK(body);
    }
}
