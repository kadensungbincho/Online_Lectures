package com.fastcampus.admin.service;

import com.fastcampus.admin.model.entity.Student;
import com.fastcampus.admin.network.Header;
import com.fastcampus.admin.network.request.StudentApiRequest;
import com.fastcampus.admin.network.response.StudentApiResponse;
import org.springframework.stereotype.Service;

@Service
public class StudentService extends BaseService<StudentApiRequest, StudentApiResponse, Student> {
    @Override
    public Header<StudentApiResponse> create(Header<StudentApiRequest> request) {
        StudentApiRequest body = request.getData();

        if (body != null) {
            Student student = Student.builder()
                    .account(body.getAccount())
                    .password(body.getPassword())
                    .status(body.getStatus())
                    .email(body.getEmail())
                    .phoneNumber(body.getPhoneNumber())
                    .registeredAt(body.getRegisteredAt())
                    .unregisteredAt(body.getUnregisteredAt())
                    .build()
                    ;

            Student newStudent = baseRepository.save(student);

            return response(newStudent);
        }

        return Header.ERROR("Empty body");
    }

    @Override
    public Header<StudentApiResponse> read(Long id) {
        return baseRepository.findById(id)
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No Student to read"));
    }

    @Override
    public Header<StudentApiResponse> update(Header<StudentApiRequest> request) {
        StudentApiRequest body = request.getData();

        return baseRepository.findById(body.getId())
                .map(entityStudent -> {
                    entityStudent
                            .setAccount(body.getAccount())
                            .setPassword(body.getPassword())
                            .setStatus(body.getStatus())
                            .setEmail(body.getEmail())
                            .setPhoneNumber(body.getPhoneNumber())
                            .setRegisteredAt(body.getRegisteredAt())
                            .setUnregisteredAt(body.getUnregisteredAt())
                            ;

                    return entityStudent;
                })
                .map(newStudent -> baseRepository.save(newStudent))
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No Student to update"));
    }

    @Override
    public Header delete(Long id) {
        return baseRepository.findById(id)
                .map(student -> {
                    baseRepository.delete(student);
                    return Header.OK();
                })
                .orElseGet(() -> Header.ERROR("No Student to delete"));
    }

    private Header<StudentApiResponse> response(Student student) {
        StudentApiResponse body = StudentApiResponse.builder()
                .id(student.getId())
                .account(student.getAccount())
                .password(student.getPassword())
                .status(student.getPassword())
                .email(student.getEmail())
                .phoneNumber(student.getPhoneNumber())
                .applyCourseList(student.getApplyCourseList())
                .build()
                ;
        return Header.OK(body);
    }
}
