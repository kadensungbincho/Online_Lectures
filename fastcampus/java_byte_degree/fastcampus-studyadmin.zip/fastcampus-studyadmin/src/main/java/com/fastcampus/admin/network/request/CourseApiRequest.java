package com.fastcampus.admin.network.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CourseApiRequest {

    private Long id;

    private String title;

    private String status;

    private String teacherName;

    private String teacherPhoneNumber;

    private String teacherEmail;

    private BigDecimal amount;
}
