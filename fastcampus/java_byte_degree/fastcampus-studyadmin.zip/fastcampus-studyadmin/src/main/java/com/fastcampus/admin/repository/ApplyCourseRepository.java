package com.fastcampus.admin.repository;

import com.fastcampus.admin.model.entity.ApplyCourse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplyCourseRepository extends JpaRepository<ApplyCourse, Long> {
}
