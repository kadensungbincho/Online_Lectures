package com.fastcampus.admin.component;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class LoginUserAuditorAware implements AuditorAware<String> {
    // https://docs.spring.io/spring-data/jpa/docs/current/reference/html/index.html#auditing.auditor-aware

    @Override
    public Optional<String> getCurrentAuditor() {
        return Optional.of("AdminServer");
    }
}
