package com.fastcampus.admin.controller.api;

import com.fastcampus.admin.controller.CrudController;
import com.fastcampus.admin.model.entity.Student;
import com.fastcampus.admin.network.request.StudentApiRequest;
import com.fastcampus.admin.network.response.StudentApiResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/student")
public class StudentController extends CrudController<StudentApiRequest, StudentApiResponse, Student> {
}
