package com.fastcampus.admin.controller.api;

import com.fastcampus.admin.controller.CrudController;
import com.fastcampus.admin.model.entity.ApplyCourse;
import com.fastcampus.admin.network.request.ApplyCourseApiRequest;
import com.fastcampus.admin.network.response.ApplyCourseApiResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/applyCourse")
public class ApplyCourseController extends CrudController<ApplyCourseApiRequest, ApplyCourseApiResponse, ApplyCourse> {
}
