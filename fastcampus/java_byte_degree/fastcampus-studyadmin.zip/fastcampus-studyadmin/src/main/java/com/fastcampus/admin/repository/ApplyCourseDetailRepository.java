package com.fastcampus.admin.repository;

import com.fastcampus.admin.model.entity.ApplyCourseDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplyCourseDetailRepository extends JpaRepository<ApplyCourseDetail, Long> {
}
