package com.fastcampus.admin.controller.api;

import com.fastcampus.admin.controller.CrudController;
import com.fastcampus.admin.model.entity.Course;
import com.fastcampus.admin.network.request.CourseApiRequest;
import com.fastcampus.admin.network.response.CourseApiResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/course")
public class CourseController extends CrudController<CourseApiRequest, CourseApiResponse, Course> {
}
