package com.fastcampus.admin.service;

import com.fastcampus.admin.model.entity.CourseDetail;
import com.fastcampus.admin.network.Header;
import com.fastcampus.admin.network.request.CourseDetailApiRequest;
import com.fastcampus.admin.network.response.CourseDetailApiResponse;
import com.fastcampus.admin.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseDetailService extends BaseService<CourseDetailApiRequest, CourseDetailApiResponse, CourseDetail> {

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public Header<CourseDetailApiResponse> create(Header<CourseDetailApiRequest> request) {
        CourseDetailApiRequest body = request.getData();

        if (body != null) {
            CourseDetail courseDetail = CourseDetail.builder()
                    .title(body.getTitle())
                    .content(body.getContent())
                    .course(courseRepository.getOne(body.getCourseId()))
                    .build()
                    ;
            CourseDetail newCourseDetail = baseRepository.save(courseDetail);

            return response(newCourseDetail);
        }

        return Header.ERROR("Empty body");
    }

    @Override
    public Header<CourseDetailApiResponse> read(Long id) {
        return baseRepository.findById(id)
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No CourseDetail to read"));
    }

    @Override
    public Header<CourseDetailApiResponse> update(Header<CourseDetailApiRequest> request) {
        CourseDetailApiRequest body = request.getData();

        return baseRepository.findById(body.getId())
                .map(entityCourseDetail -> {
                    entityCourseDetail
                            .setTitle(body.getTitle())
                            .setContent(body.getContent())
                            .setCourse(courseRepository.getOne(body.getCourseId()))
                            ;
                    return entityCourseDetail;
                })
                .map(newCourseDetail -> baseRepository.save(newCourseDetail))
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No CourseDetail to update"));
    }

    @Override
    public Header delete(Long id) {
        return baseRepository.findById(id)
                .map(courseDetail -> {
                    baseRepository.delete(courseDetail);
                    return Header.OK();
                })
                .orElseGet(() -> Header.ERROR("No CourseDetail to delete"));
    }

    private Header<CourseDetailApiResponse> response(CourseDetail courseDetail) {
        CourseDetailApiResponse body = CourseDetailApiResponse.builder()
                .id(courseDetail.getId())
                .title(courseDetail.getTitle())
                .content(courseDetail.getContent())
                .courseId(courseDetail.getCourse().getId())
                .build()
                ;

        return Header.OK(body);

    }
}
