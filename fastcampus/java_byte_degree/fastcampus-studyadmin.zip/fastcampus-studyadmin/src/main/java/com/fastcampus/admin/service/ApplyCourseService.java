package com.fastcampus.admin.service;

import com.fastcampus.admin.model.entity.ApplyCourse;
import com.fastcampus.admin.network.Header;
import com.fastcampus.admin.network.request.ApplyCourseApiRequest;
import com.fastcampus.admin.network.response.ApplyCourseApiResponse;
import com.fastcampus.admin.repository.CourseRepository;
import com.fastcampus.admin.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplyCourseService extends BaseService<ApplyCourseApiRequest, ApplyCourseApiResponse, ApplyCourse> {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public Header<ApplyCourseApiResponse> create(Header<ApplyCourseApiRequest> request) {
        ApplyCourseApiRequest body = request.getData();

        if (body != null) {
            ApplyCourse applyCourse = ApplyCourse.builder()
                    .status(body.getStatus())
                    .progressRate(body.getProgressRate())
                    .isComplete(body.getIsComplete())
                    .expireAt(body.getExpireAt())
                    .course(courseRepository.getOne(body.getCourseId()))
                    .student(studentRepository.getOne(body.getStudentId()))
                    .build()
                    ;
            ApplyCourse newApplyCourse = baseRepository.save(applyCourse);

            return response(newApplyCourse);
        }

        return Header.ERROR("Empty body");
    }

    @Override
    public Header<ApplyCourseApiResponse> read(Long id) {
        return baseRepository.findById(id)
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No ApplyCourse to read"));
    }

    @Override
    public Header<ApplyCourseApiResponse> update(Header<ApplyCourseApiRequest> request) {
        ApplyCourseApiRequest body = request.getData();

        return baseRepository.findById(body.getId())
                .map(entityApplyCourse -> {
                    entityApplyCourse
                            .setStatus(body.getStatus())
                            .setProgressRate(body.getProgressRate())
                            .setIsComplete(body.getIsComplete())
                            .setExpireAt(body.getExpireAt())
                            .setCourse(courseRepository.getOne(body.getCourseId()))
                            .setStudent(studentRepository.getOne(body.getStudentId()))
                            ;

                    return entityApplyCourse;
                })
                .map(newApplyCourse -> baseRepository.save(newApplyCourse))
                .map(this::response)
                .orElseGet(() -> Header.ERROR("No ApplyCourse to update"));
    }

    @Override
    public Header delete(Long id) {
        return baseRepository.findById(id)
                .map(applyCourse -> {
                    baseRepository.delete(applyCourse);
                    return Header.OK();
                })
                .orElseGet(() -> Header.ERROR("No ApplyCourse to delete"));
    }

    private Header<ApplyCourseApiResponse> response(ApplyCourse applyCourse) {
        ApplyCourseApiResponse body = ApplyCourseApiResponse.builder()
                .id(applyCourse.getId())
                .status(applyCourse.getStatus())
                .progressRate(applyCourse.getProgressRate())
                .isComplete(applyCourse.getIsComplete())
                .expireAt(applyCourse.getExpireAt())
                .courseId(applyCourse.getCourse().getId())
                .studentId(applyCourse.getStudent().getId())
                .build()
                ;

        return Header.OK(body);
    }
}
