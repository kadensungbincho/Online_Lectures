package manager;

public interface SalesRatio {
    double getSalesRatio(double price);
    void printSalesReport(double price);
}



