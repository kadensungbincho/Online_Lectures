package member;

public enum Family {
    FAMILY, VIP;
}
